/* ===== Carrossel de frases, brilho do mouse, jogo de Mitos e fatos ===== */
(function(){
  /* Carrossel de frases */
  var frases=[].slice.call(document.querySelectorAll('.frase'));
  var pontosEl=document.getElementById('pontos');
  var btnPausa=document.getElementById('pausa');
  var atual=0,pausado=false,timer=null;
  var reduz=window.matchMedia&&window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  var pontos=frases.map(function(_,i){
    var b=document.createElement('button');b.type='button';
    b.setAttribute('aria-label','Ir para a frase '+(i+1)+' de '+frases.length);
    b.addEventListener('click',function(){ir(i)});pontosEl.appendChild(b);return b;
  });
  function mostrar(){frases.forEach(function(f,i){var a=i===atual;f.classList.toggle('ativa',a);f.setAttribute('aria-hidden',a?'false':'true');pontos[i].classList.toggle('ativo',a);if(a){pontos[i].setAttribute('aria-current','true')}else{pontos[i].removeAttribute('aria-current')}})}
  function ir(i){atual=(i+frases.length)%frases.length;mostrar();parar();iniciar()}
  function iniciar(){if(!pausado&&!timer){timer=setInterval(function(){atual=(atual+1)%frases.length;mostrar()},6000)}}
  function parar(){if(timer){clearInterval(timer);timer=null}}
  function definirPausa(p){pausado=p;btnPausa.textContent=p?'Retomar':'Pausar';btnPausa.setAttribute('aria-label',p?'Retomar a troca automática de frases':'Pausar a troca automática de frases');if(p){parar()}else{iniciar()}}
  document.getElementById('anterior').addEventListener('click',function(){ir(atual-1)});
  document.getElementById('proxima').addEventListener('click',function(){ir(atual+1)});
  btnPausa.addEventListener('click',function(){definirPausa(!pausado)});
  mostrar();
  if(reduz){definirPausa(true)}else{iniciar()}

  /* Brilho suave que acompanha o cursor */
  var br=document.getElementById('brilho');
  if(br&&!reduz&&window.matchMedia('(hover:hover)').matches){
    var tx=0,ty=0,x=0,y=0,rodando=false;
    function anima(){x+=(tx-x)*.16;y+=(ty-y)*.16;br.style.transform='translate('+x+'px,'+y+'px)';
      if(Math.abs(tx-x)>.4||Math.abs(ty-y)>.4){requestAnimationFrame(anima)}else{rodando=false}}
    window.addEventListener('pointermove',function(e){tx=e.clientX;ty=e.clientY;if(!br.classList.contains('on')){x=tx;y=ty;br.classList.add('on')}
      if(!rodando){rodando=true;requestAnimationFrame(anima)}},{passive:true});
    document.addEventListener('pointerleave',function(){br.classList.remove('on')});
  }

  /* Brilho que segue o cursor nos blocos */
  [].slice.call(document.querySelectorAll('.card')).forEach(function(c){
    c.addEventListener('pointermove',function(e){var r=c.getBoundingClientRect();c.style.setProperty('--mx',(e.clientX-r.left)+'px');c.style.setProperty('--my',(e.clientY-r.top)+'px')});
  });

  /* Jogo de mito ou fato */
  var itens=[
    {t:'Antibiótico cura gripe.',r:'mito',e:'A gripe é causada por vírus. Antibióticos agem contra bactérias e não têm efeito sobre ela.'},
    {t:'Lavar as mãos com água e sabão reduz o risco de infecções.',r:'fato',e:'A higiene das mãos é uma das medidas mais simples e eficazes para evitar a transmissão de doenças.'},
    {t:'Só se pega resfriado em dia de frio.',r:'mito',e:'O resfriado é causado por vírus. O frio não é a causa; ficar em ambientes fechados e cheios facilita a transmissão.'}
  ];
  var i=0;
  var afirm=document.getElementById('afirmacao'),res=document.getElementById('resultado'),cont=document.getElementById('contador'),prox=document.getElementById('proximaAfirmacao');
  var botoes=[].slice.call(document.querySelectorAll('.jogo .resp button'));
  function carregar(){
    var it=itens[i];afirm.textContent=it.t;cont.textContent=(i+1)+' de '+itens.length;
    res.className='resultado';res.textContent='Escolha uma resposta para ver a explicação.';
    botoes.forEach(function(b){b.disabled=false;b.classList.remove('escolhida')});prox.hidden=true;
  }
  botoes.forEach(function(b){b.addEventListener('click',function(){
    var it=itens[i],acertou=b.getAttribute('data-r')===it.r;
    botoes.forEach(function(x){x.disabled=true});b.classList.add('escolhida');
    res.className='resultado '+(acertou?'certo':'errado');
    res.innerHTML='<strong>'+(acertou?'Acertou! É '+it.r+'.':'Quase! Na verdade é '+it.r+'.')+'</strong>'+it.e;
    prox.hidden=false;prox.focus();
  })});
  prox.addEventListener('click',function(){i=(i+1)%itens.length;carregar();botoes[0].focus()});
  carregar();
})();

/* ===== Login e painel (demonstração) ===== */
(function(){
  var home=document.getElementById('inicio'),pLogin=document.getElementById('login-pagina'),pPainel=document.getElementById('painel');
  var logada=false;
  function rota(){
    var h=location.hash;
    var alvo=h==='#painel'?'painel':h==='#login'?'login':'home';
    if(alvo==='painel'&&!logada){location.hash='#login';return}
    home.hidden=alvo!=='home';pLogin.hidden=alvo!=='login';pPainel.hidden=alvo!=='painel';
    if(alvo==='home'){var el=h.length>1&&document.getElementById(h.slice(1));if(el)el.scrollIntoView();else window.scrollTo(0,0)}
    else{window.scrollTo(0,0);var f=alvo==='login'?document.getElementById('lg-user'):null;if(f)f.focus({preventScroll:true})}
    if(alvo==='login')logada=false;
  }
  window.addEventListener('hashchange',rota);
  document.getElementById('form-login').addEventListener('submit',function(e){e.preventDefault();logada=true;location.hash='#painel'});

  function T(id,rot,dica){return {t:'t',id:id,l:rot,d:dica}}
  function A(id,rot,dica){return {t:'a',id:id,l:rot,d:dica}}
  var CATS={
    'Patologias':[T('p-nome','Nome da patologia'),A('p-oque','O que é','Em poucas linhas, com palavras simples'),A('p-sint','Sintomas e causas'),A('p-diag','Diagnóstico e tratamento'),A('p-prev','Prevenção e quando procurar ajuda'),A('p-fontes','Fontes consultadas','Uma por linha, com o link')],
    'Quiz':[A('q-perg','Pergunta'),T('q-a','Alternativa A'),T('q-b','Alternativa B'),T('q-c','Alternativa C'),T('q-d','Alternativa D'),{t:'s',id:'q-ok',l:'Alternativa correta',o:['A','B','C','D']},A('q-exp','Explicação curta'),T('q-fonte','Fonte')],
    'Mitos e fatos':[A('m-afirm','A afirmação'),{t:'r',id:'m-tipo',l:'É mito ou fato?',o:['Mito','Fato']},A('m-exp','Explicação em linguagem simples'),T('m-fonte','Fonte')],
    'Notícias':[T('n-tit','Título'),A('n-res','Resumo','2 a 3 linhas'),A('n-txt','Texto completo'),{t:'d',id:'n-data',l:'Data'},{t:'u',id:'n-link',l:'Link da fonte'},{t:'f',id:'n-img',l:'Imagem',d:'opcional'}]
  };
  var abas=document.getElementById('abas'),corpo=document.getElementById('form-corpo'),tit=document.getElementById('form-titulo'),st=document.getElementById('status');
  function campo(c){
    var d=c.d?' <small>('+c.d+')</small>':'',h;
    if(c.t==='t')h='<input type="text" id="'+c.id+'">';
    else if(c.t==='a')h='<textarea id="'+c.id+'"></textarea>';
    else if(c.t==='d')h='<input type="date" id="'+c.id+'">';
    else if(c.t==='u')h='<input type="url" id="'+c.id+'" placeholder="https://">';
    else if(c.t==='f')h='<input type="file" id="'+c.id+'" accept="image/*">';
    else if(c.t==='s')h='<select id="'+c.id+'">'+c.o.map(function(o){return '<option>'+o+'</option>'}).join('')+'</select>';
    else if(c.t==='r'){return '<div class="campo" role="radiogroup" aria-labelledby="'+c.id+'-l"><span class="leg" id="'+c.id+'-l">'+c.l+'</span><div class="radios">'+c.o.map(function(o,i){return '<label><input type="radio" name="'+c.id+'"'+(i?'':' checked')+'> '+o+'</label>'}).join('')+'</div></div>'}
    return '<div class="campo"><label for="'+c.id+'">'+c.l+d+'</label>'+h+'</div>';
  }
  function mostrar(nome){
    tit.textContent='Novo conteúdo: '+nome;st.textContent='';
    corpo.innerHTML=CATS[nome].map(campo).join('');
    Array.prototype.forEach.call(abas.children,function(b){b.setAttribute('aria-selected',b.textContent===nome)});
  }
  Object.keys(CATS).forEach(function(n){var b=document.createElement('button');b.type='button';b.setAttribute('role','tab');b.textContent=n;b.addEventListener('click',function(){mostrar(n)});abas.appendChild(b)});
  document.getElementById('form-conteudo').addEventListener('click',function(e){
    var a=e.target.getAttribute&&e.target.getAttribute('data-acao');if(!a)return;
    st.textContent=a==='publicar'?'Pronto! (demonstração: nada foi publicado de verdade)':'Rascunho salvo (demonstração).';
  });
  mostrar('Patologias');
  rota();
})();
